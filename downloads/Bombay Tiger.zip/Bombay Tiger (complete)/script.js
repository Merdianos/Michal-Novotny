const bar = document.getElementById("bar");
const navbar = document.getElementById("navbar");
const close = document.getElementById("closeB");
let naviLink = document.querySelectorAll(".navi-link-js");

let changingLogo = document.querySelector(".logo-img");
const debounce = (fn) => {
  let frame;

  return (...params) => {
    if (frame) {
      cancelAnimationFrame(frame);
    }
    frame = requestAnimationFrame(() => {
      fn(...params);
    });
  };
};

const storeScroll = () => {
  document.documentElement.dataset.scroll = window.scrollY;
  if (document.documentElement.dataset.scroll !== "0") {
    changingLogo.src = "./img/logo2.png";
  } else {
    changingLogo.src = "./img/logo.png";
  }
};
document.addEventListener("scroll", debounce(storeScroll), { passive: true });

storeScroll();

$(document).on("click", ".menu-link-js", function (e) {
  e.preventDefault();

  var $self = $(this);
  $(".menu-link-js").removeClass("color-active");
  $self.addClass("color-active");
  var target = $(this).attr("href");

  $(".menu-tab-js").hide();
  $(target).fadeIn();
});

bar.addEventListener("click", function () {
  navbar.classList.toggle("mobile");
  if (navbar.className === "mobile") {
    naviLink.forEach((navi) =>
      navi.addEventListener("click", function () {
        navbar.classList.remove("mobile");
      })
    );
  }
});
