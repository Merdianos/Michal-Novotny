

const form = document.getElementById("book-a-call-form")
const firstName = document.getElementById("name")
const phone = document.getElementById("phone")
const email = document.getElementById("email")
const company = document.getElementById("company")
const message = document.getElementById("message")
const h2 = document.getElementById("book-a-call-h2")
const span1 = document.getElementById("span1")
const span2 = document.getElementById("span2")
const lnk = document.getElementById('lnk')
const mobileButton = document.getElementById("mobile-btn")
const cancelButton = document.getElementById("cancel-button")
const mobileMenu = document.getElementsByClassName("mobile-menu")



$(document).on("click", ".services-link-js", function(e){
    e.preventDefault();

var $self = $(this);
$(".services-link-js").removeClass("color-services");
$self.addClass("color-services");
var target = $(this).attr("href");

$(".services-tab-js").hide();
$(target).fadeIn();
})



$(function() {
  $(form).hover(function() {
    $(h2).css('color', 'var(--submain-color)');
    $(span1).css('color', 'var(--submain-color)');
    $(span2).css('color', 'var(--submain-color)');
  }, function() {
    $(h2).css('color', '');
    $(span1).css('color', '');
    $(span2).css('color', '');
  });
});


form.addEventListener("submit", (e) => {
  checkInputs()
    if (firstName.parentElement.className === "form-control success" && phone.parentElement.className === "form-control success" && email.parentElement.className === "form-control success" && company.parentElement.className === "form-control success" && message.parentElement.className === "form-control success") {
    end()
    } else {
      e.preventDefault()
    }

})


function checkInputs() {
  const firstNameV = firstName.value.trim()
  const phoneV =  phone.value.trim()
  const emailV = email.value.trim()
  const companyV = company.value.trim()
  const messageV = message.value.trim()

  if(firstNameV === '') {

    setErrorFor(firstName, "Name cannot be blank")
  } else if(!isName(firstNameV)) {
    setErrorFor(firstName, "Name can only consists of letters")
  } else {

    setSuccessFor(firstName)
  }

  if(phoneV === '') {
    setErrorFor(phone, "Phone cannot be blank")
  } else if(!isPhone(phoneV)) {
    setErrorFor(phone, "Not a valid phone number")
  }
   else {
    setSuccessFor(phone)
  }

	if(emailV === '') {
		setErrorFor(email, 'Email cannot be blank')
  } else if (!isEmail(emailV)) {
		setErrorFor(email, 'Not a valid email');
	} else {
		setSuccessFor(email);
	}

  if(companyV === '') {
    setErrorFor(company, "Company name cannot be blank")
  } else {
    setSuccessFor(company)
  }

  if(messageV === '') {
    setErrorFor(message, "Message cannot be blank")
  } else {
    setSuccessFor(message)
  }

  messageV.value = ""
}

mobileButton.addEventListener("click", function(e) {
  $(mobileMenu).css('display','block')
})

cancelButton.addEventListener("click", function(e) {
  $(mobileMenu).css('display','none')
})

function setErrorFor(input, message) {
  const formControl = input.parentElement
  const span = formControl.querySelector('span')

  span.innerText = message
  formControl.className = 'form-control error'
}

function setSuccessFor(input) {
  const formControl = input.parentElement
  formControl.className = "form-control success"
}

function isName(name) {
  return /^[A-Za-z- ]+$/.test(name)
}

function isEmail(email) {
  	return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);
}

function isPhone(phone) {
  return /^\+(?:[0-9] ?){6,14}[0-9]$/.test(phone)
}

function end() {
        $(message).val('');
        lnk.click()
      return true
}
