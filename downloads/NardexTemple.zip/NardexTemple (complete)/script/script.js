AOS.init();
const form = document.getElementById("get-started-form");
const firstName = document.getElementById("name");
const phone = document.getElementById("phone");
const email = document.getElementById("email");
const company = document.getElementById("company");
const sections = document.querySelectorAll("section");
const navLi = document.querySelectorAll("nav .header-ul li");
let header = document.querySelector(".page-header");
const bar = document.getElementById("bar");
const container = document.querySelector(".container");

window.onscroll = () => {
  scrollFunction();
  var current = "";

  sections.forEach((section) => {
    const sectionTop = section.offsetTop;
    if (window.pageYOffset >= sectionTop - 150) {
      current = section.getAttribute("id");
    }
  });

  navLi.forEach((li) => {
    li.classList.remove("active");
    if (li.classList.contains(current)) {
      li.classList.add("active");
    }
  });
};

function scrollFunction() {
  if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
    document.querySelector(".page-header").style.height = "80px";
  }
}

bar.addEventListener("click", function () {
  stateActive(container);
});

function stateActive(object) {
  if (object.className === "container") {
    object.classList.add("active");
  } else {
    object.classList.remove("active");
  }
}

form.addEventListener("submit", (e) => {
  checkInputs();
  if (
    firstName.parentElement.className === "form-control success" &&
    phone.parentElement.className === "form-control success" &&
    email.parentElement.className === "form-control success" &&
    company.parentElement.className === "form-control success"
  ) {
    end();
  } else {
    e.preventDefault();
  }
});

function checkInputs() {
  const firstNameV = firstName.value.trim();
  const phoneV = phone.value.trim();
  const emailV = email.value.trim();
  const companyV = company.value.trim();

  if (firstNameV === "") {
    setErrorFor(firstName);
  } else if (!isName(firstNameV)) {
    setErrorFor(firstName);
  } else {
    setSuccessFor(firstName);
  }

  if (phoneV === "") {
    setErrorFor(phone);
  } else if (!isPhone(phoneV)) {
    setErrorFor(phone);
  } else {
    setSuccessFor(phone);
  }

  if (emailV === "") {
    setErrorFor(email);
  } else if (!isEmail(emailV)) {
    setErrorFor(email);
  } else {
    setSuccessFor(email);
  }

  if (companyV === "") {
    setErrorFor(company);
  } else {
    setSuccessFor(company);
  }
}

function setErrorFor(input) {
  const formControl = input.parentElement;
  formControl.className = "form-control error";
}

function setSuccessFor(input) {
  const formControl = input.parentElement;
  formControl.className = "form-control success";
}

function isName(name) {
  return /^[A-Za-z- ]+$/.test(name);
}

function isEmail(email) {
  return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(
    email
  );
}

function isPhone(phone) {
  return /^\+(?:[0-9] ?){6,14}[0-9]$/.test(phone);
}

function end() {
  lnk.click();
  return true;
}
